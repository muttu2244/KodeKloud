 # Pushing to remote repositories
   - Take me to [Video Tutorial](https://kodekloud.com/courses/1085975/lectures/23241065)
   
 In this section, we will take a look at pushing to remote repositories
 
 #### In order to keep our local and remote repo in sync, we have to push the data from local repo to remote repo
 - To push data from local to remote repo
   ```
   $ git push origin master
   ```
   
   ![gpush](../../images/gpush.PNG)
   
   
